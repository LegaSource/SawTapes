# Saw Tapes
Saw Tapes is a mod that adds new mini-games.
These games are triggered by a tape from which the infamous killer Jigsaw will explain the rules of the game to you.

# Games
When one of the players enters the effect zone of a tape, a gas is released, causing them and other random players to faint.
The group is teleported to the dungeon's main entrance. There, the tape and, if necessary, items are made available to them.
A player must activate the tape to start the game

Will you rise to the challenge?

## Survival Game
- Monsters progressively spawn and hunt the players
- The players must survive until the time runs out
- A special item (Pursuer Eye) can be used to teleport a monster to another distant player
- These items spawn throughout the dungeon and disappear once the game ends
- The game is won if a player escapes alive

## Hunting Game
- Each player wears a Reverse Bear Trap on their head, which activates after a certain amount of time
- A key is needed to remove the device, and it is hidden inside one or more monsters
- Each player must defeat one of these monsters and retrieve the key before time runs out
- There is only one monster per participant, so choose wisely to avoid conflicting with another player
- The game is won if a player escapes alive

## Escape Game
- Two players are chained together and must progress while avoiding traps
- The spawn probability for each trap is configurable and you can add or remove traps as desired (traps from other mods can be used; configurations for traps from 'Code Rebirth' are included by default)
- If one of the players dies, the second is no longer chained to anything and can move freely, making it easier for them to reach the saw
- A saw awaits at the end of the path and at least one player must reach it to win
- The saw becomes visible throught the walls when players get close enough to it and can be teleported using the secondary action key
- If no player reaches the saw before time runs out, everyone dies
- The game is won if a player escapes alive

# Subtitles configurations
The 'ST.subtitles.json' file is created when the game is launched (if they don't already exist), and you can find it in the 'config' folder.

This file allows you to change the subtitles:
'timestamp' is the field that corresponds to the moment when the sentence is displayed on the screen according to the recording duration of the tape and 'text' is the sentence displayed.

## More informations
For any feedback/suggestions or questions, you can reach me on the 'Lethal Company Modding' Discord server (https://discord.gg/9rZjs3qZ) under the same name (username lega2039) or the SawTapes thread.
DMs are welcome.

# Attributions

## Billy On Bike
"Billy On Bike" (https://skfb.ly/oLRPs) by LostBoyz2078 is licensed under Creative Commons Attribution-NonCommercial (http://creativecommons.org/licenses/by-nc/4.0/).

Change made:
- Duplicated part of the model to create the Billy puppet item, which can now be grabbed

## Reverse Bear Trap
"Reverse Bear Trap" (https://skfb.ly/oSWDH) by ✩~𝙼𝚒𝚔𝚘 𝙲𝚑𝚊𝚗~✩ is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).

Change made:
- Slight jaw reduction, allowing the player to see better ahead

## Saw Tool
"Saw Tool" (https://skfb.ly/6pPzn) by TraianDumbrava is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).