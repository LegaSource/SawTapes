# Saw Tapes
Saw Tapes is a mod that adds new mini-games.
These games are triggered by a tape from which the infamous killer Jigsaw will explain the rules of the game to you.

# Games
When one of the players enters the effect zone of a tape, a gas is released, causing them and other random players to faint.
The group is teleported to the dungeon's main entrance. There, the tape and, if necessary, items are made available to them.
A player must activate the tape to start the game.

Will you rise to the challenge?

## Survival Game
<details>
<summary>Description</summary>

### Setup
- Each player starts equipped with:
	- A shovel
	- A miniature Billy puppet

### Gameplay
- Throughout the mini-game, random monsters spawn every 10 seconds around each player
- Players must survive while managing the constant pressure of these spawns

### Billy Puppet Features
- Can be used once every 20 seconds
- Allows the player to teleport a targeted monster to another distant player, creating opportunities for cooperation… or betrayal

### End of the Game
The mini-game ends when the timer reaches zero:
- Victory: at least one player survives
- Defeat: no survivors remain
</details>

<details>
<summary>Reward</summary>

### Reward
Miniature Billy Doll with the Sprint Burst Addon
- Effect on use: grants the player a 100% speed boost for 5 seconds
- Cooldown: 45 seconds
</details>

## Hunting Game
<details>
<summary>Description</summary>

### Setup
- Each player starts equipped with:
	- A shovel
	- A miniature Billy puppet
	- A Reverse Bear Trap
- At the start of the game, a monster spawns for each participating player, at a certain distance.
- Each monster has a key in its stomach.
- Since each key can only be used once, players must choose between:
- Killing their own monster
- Teaming up to defeat them more easily
- Betraying others to steal a key at their expense

### Billy Puppet Features
- The puppet can be used every 20 seconds
- When activated, it reveals the monsters’ auras for 5 seconds

### End of the Game
- The mini-game ends when one of the following conditions is met:
- Victory: all players have removed their traps
- Defeat: all players have died
- Time runs out:
	- Players still trapped by a Reverse Bear Trap die
	- However, the game is still considered a success as long as at least one player survives
</details>

<details>
<summary>Reward</summary>

### Reward
Miniature Billy Doll with the Hunter’s Mark Addon
- Effect on use: summons a Billy that moves randomly for 30 seconds
- During this time, the Billy reveals the aura of all monsters to all players at regular intervals
- Monsters listed in the configuration are excluded from the effect
- The Billy disappears automatically at the end of 30 seconds
- Cooldown: 180 seconds
</details>

## Escape Game
<details>
<summary>Description</summary>

### Setup
- All players start chained to each other
- Each player is equipped with a shovel
- A saw spawns at a distance, serving as the group’s main objective

### Gameplay
- Players must reach the saw to cut their chains
- The saw’s aura is revealed to one player every 30 seconds, lasting 30 seconds
- Player death:
	- The chain linking them is removed
	- This creates opportunities for remaining players to betray others to gain more freedom of movement

### Traps
- Spawn around each player every 5 seconds
- Can be destroyed with the shovel, disappearing in smoke (only traps generated during this mini-game)

### End of the Game
The mini-game ends when:
- Victory: one player uses the saw to free all participants
- Defeat: the timer reaches zero and all players are killed
</details>

<details>
<summary>Reward</summary>

### Reward
Saw with the Bleeding Chains Addon
- Effect on use: summons chains on the targeted monster, which then receives the Bleeding status
- Bleeding status: deals damage every second for 10 seconds and heals the player
- Offensive interaction: when a bleeding monster is attacked, the attacking player is also healed
- Cooldown: 45 seconds
</details>

## Explosive Game
<details>
<summary>Description</summary>

### Setup
- One player starts holding a bomb
- The bomb emits a ticking sound that speeds up while being held
- The bomb is heavy, significantly slowing down the carrier
- A container spawns at the start and remains visible throughout the mini-game

### Gameplay
- The ticking has a random timer
- To reset the ticking, the bomb can be passed to another player by targeting them
- Players’ goal is to place the bomb in the container so it explodes safely, without killing anyone
- Risks and Strategy:
	- If the bomb is dropped, if the timer reaches zero, or if the global timer runs out, the bomb explodes
	- All players near the explosion are at risk
	- Players can choose to abandon the carrier, letting them explode alone

### End of the Game
The mini-game ends when the bomb explodes:
- Victory: at least one player survives
- Defeat: all players die in the explosion
</details>

<details>
<summary>Reward</summary>

### Reward
Miniature Billy Doll with the Final Detonation Addon
- Effect on use: summons a Billy on a tricycle that moves toward the targeted monster
- The Billy emits a ticking sound with a random timer
- Explosion: when the timer ends, the Billy explodes, potentially killing monsters and players nearby
- Normally invulnerable monsters can also be killed, except those listed in the configuration
- Cooldown: 600 seconds
</details>

# Hidden Reward
<details>
<summary>Spoilers</summary>

## Miniature Billy Puppet (with Addon)

### How to Obtain
To get this special puppet, you need to:
- Complete several mini-games to collect the regular puppets given by the Billys on their tricycles
- Break these puppets (using a shovel or another weapon):
	- Each destroyed puppet drops a broken part (head or body)
	- The value of these pieces is much lower than that of the intact puppet
- Assemble the two different parts:
	- Hold one piece and click on the other
	- Once combined, they reform into a miniature Billy puppet containing the addon
	
## Addon : Jigsaw’s Judgement

### Cooldown : 600s
- As long as the addon is in the inventory and not on cooldown, it prevents the player’s immediate death
- Instead of dying, the player is teleported into Jigsaw’s bathroom (if not already in a Saw mini-game)

### Game Flow
- The player is chained up, with a saw placed next to them
- Billy appears and tells them they must play to survive

### Two options are available
- Use the saw:
	- The player frees themselves immediately
	- They survive, but lose a limb, which inflicts a -50% movement speed penalty until the end of the day
- Search for a key:
	- It may be hidden in 3 random spots
	- Each attempt triggers a sliding puzzle on the screen
	- The player must solve up to 3 puzzles within the time limit to have a chance at finding the key
	- If the key is found and used, the player frees themselves without any penalty
</details>

# Subtitles configurations
The 'ST.subtitles.json' file is created when the game is launched (if they don't already exist), and you can find it in the 'config' folder.

This file allows you to change the subtitles:
'timestamp' is the field that corresponds to the moment when the sentence is displayed on the screen according to the recording duration of the tape and 'text' is the sentence displayed.

## More informations
For any feedback/suggestions or questions, you can reach me on the 'Lethal Company Modding' Discord server (https://discord.gg/9rZjs3qZ) under the same name (username lega2039) or the SawTapes thread.
DMs are welcome.

# Attributions

## Billy On Bike
"Billy On Bike" (https://skfb.ly/oLRPs) by LostBoyz2078 is licensed under Creative Commons Attribution-NonCommercial (http://creativecommons.org/licenses/by-nc/4.0/).

Change made:
- Duplicated part of the model to create the Billy puppet item, which can now be grabbed

## Reverse Bear Trap
"Reverse Bear Trap" (https://skfb.ly/oSWDH) by ✩~𝙼𝚒𝚔𝚘 𝙲𝚑𝚊𝚗~✩ is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).

Change made:
- Slight jaw reduction, allowing the player to see better ahead

## Saw Tool
"Saw Tool" (https://skfb.ly/6pPzn) by TraianDumbrava is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).

## Metal Storage Box
"Metal Storage Box" (https://skfb.ly/6WNuG) by al0sral0 is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).

## Bomb
"Bomb" (https://skfb.ly/JXzQ) by heedongq is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).

## Saw Bathroom
https://www.cgtrader.com/free-3d-models/architectural/engineering/saw-bathroom-3d-model

# Credits
- aglitchednpc and their testing team – and for contributing some great ideas!