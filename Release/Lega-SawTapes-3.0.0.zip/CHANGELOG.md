# CHANGELOG

## Version 3.0.0
- Rewrote a large part of the mod and added common features into LegaFusionCore
- Added LegaFusionCore as a dependency
- Reworked spawn/teleport effects (ground portals)
- Players are no longer blocked inside the dungeon during a mini-game, but when the ship takes off, all players still undergoing trials are instantly killed
- Added a config where you can list players (names) who shouldn't participate (in case some people in a group don’t enjoy the mod, but others do)
- Improved the spawn increment system (default increased to 15, but it only increments for a random mini-game and only if none of them spawned during the run)
- The tape is now destroyed at the end of a mini-game, preventing multiple plays in the same day
- Added a hidden reward featuring a special mini-game

#### Hunting Game
- Replacement of the Monster Eye with a miniature Billy puppet and modification of the item’s functionality:
	- It no longer drops from monsters
	- Participating players now start the mini-game with one in hand and can use it with a 20s cooldown by default
	- Adjusted the default values for seeing monster auras with the Puppet (5s by default)
- Removed the aura visibility at the start of the mini-game (no longer necessary with the Puppet)
- Added a new reward - Hunter's Mark addon

#### Survival Game
- Replacement of the Monster Eye with a miniature Billy puppet
- Added a new reward - Sprint Burst addon

#### Escape Game
- Reworked the mini-game to make it playable in any indoor map and with more than two players
- Added a new reward - Bleeding Chains addon

#### Explosive Game
- Removed the second part of the mini-game with the Hoarding Bug and the key – a 'chase-style' mini-game like this may be added later
- Added a new reward - Final Detonation addon

## Version 2.0.3
- Added a message when a non-participating player grabs or uses items required for the game (Saw/Saw Key)
- During player teleportation, the player who triggered the tape will now immediately receive it in hand, and if needed for the mini-game, all players will directly have shovels in hand
- Renamed Pursuer Eye to Monster Eye
- Improved aura
- Fixed FallToGround calls following method changes in update v70

#### Survival Game
- Monster Eye changes: now only one will be given to all players (immediately in hand upon teleportation), with unlimited uses and a 20s cooldown
- Mini-game nerf: changed from 1 monster spawn every 5s per player to 1 every 10s

#### Escape Game
- Fixed a bug where chains wouldn’t despawn if players died before playing the cassette

#### Explosive Game
- Removed slowdown effect during bomb transfer

## Version 2.0.2
- Game version update

## Version 2.0.1
- Added a config to limit the number of mini-games per tape (if a mini-game is lost too many times in a row, it will no longer trigger)
- Added a new mini-game: 'Explosive Game'
- Nerfed the saw: it can now only be used against monsters that are normally killable
- Fixed Billy on his tricycle not despawning when picked up by a client
- Reworked aura system so each aura is now handled independently
- Object/player auras now appear in yellow
- Monster auras remain red
- A few other fixes I probably forgot to mention

## Version 2.0.0
- Rewriting the mod and reworking the mini-games
- All games now trigger with the gassing system
- Modified the mini-games to introduce an element of trust/betrayal in each of them
- A value is now assigned to the tapes at the end of the mini-games and they can be sold (added a config for the value)
- Reorganized some configs for better clarity
- It is recommended to delete the config file and the ST.subtitles.json file to let them reload

#### Survival Game:
- Removed the ST.survival_game.json file
- Enemies are randomly selected from the enemy list in the config
- The game can now be played multiplayer and throughout the entire dungeon (one monster spawns per player at regular intervals)
- Shovels have been added for each player
- Added a specific mechanic for the Pursuer Eye in this game: it allows teleporting a targeted enemy to the furthest player, introducing an element of betrayal in the mini-game
- Pursuer Eyes can be found throughout the dungeon during the game and disappear at the end of the round

#### Hunting Game
- The game can now be played multiplayer (one monster spawns per player and all players can see its aura – requiring players to coordinate well to avoid conflict)
- Added a config for the aura duration on enemies provided by the Pursuer Eye
- Reversed the enemy list; it now enumerates spawnable enemies

#### Escape Game
- When a player dies, the other player is no longer killed; the latter can now progress more freely towards the saw
- Shovels have been added for each player – will you use them to sacrifice your partner to ease your progress through the dungeon?

## Version 1.1.6
- Game version update
- Added a new mini-game: 'Escape Game'
- Extensively refactored code to allow all mini-games to share common logic
- Added a new 'Gassing System' tab in the configuration menu for settings related to tapes triggered by gassing a player
- Gassed players are no longer targetable during the spawn animation (and for 1 second afterward to allow them time to react)
- Tapes now despawn when the ship takes off, as having multiple tapes in the same session could cause issues

#### Survival Game:
- Adjusted all monster hordes (mostly nerfs) and to make them more balanced relative to each other + added new hordes
- Added new possible interiors: Circus Facility, Liminal Pool Rooms, Slaughterhouse, Blue Mines, Gray Apartments (very rare) and Black Mesa

#### Hunting Game
- If the tracked monster is dead, the key's aura will be visible instead at the start of the mini-game or via the Pursuer Eye
- Moved the 'Gassed distance' and 'Cheat distance' settings to the 'Gassing System' tab

## Version 1.1.5
- Added compatibility with the Yavin IV and CastleGrounds interiors for the Survival Game
	- delete the ST.survival_game.json file to allow it to regenerate with the new configuration
- Fixed a bug that altered rarity configurations in the config file

## Version 1.1.4
- Improved aura for the Hunting Game and fixed some monsters that were not showing it

## Version 1.1.3
- Added checks for potential NREs
- Added a HUD section in the settings
- Moved the subtitles enable option to the HUD section
- Added two settings, 'Chrono pos X' and 'Chrono pos Y,' to adjust the position of the chrono text
- Modified the chrono text to make it easier to reposition

## Version 1.1.2
- Changed the teleportation system during the setup of the Hunting Game: now the player, along with the tape and shovel, are teleported to the main entrance, preventing the player from spawning in a location where they could get stuck
- Fixed an issue that allowed the Hunting Game key to be dropped on all monsters of the same type as the one being hunted
- The monster spawned by the Hunting Game will now despawn at the end of the mini-game if it hasn’t been killed
- Prevented mini-games with a rarity of 0 from having their spawn rate increased by the 'Rarity increment' config

## Version 1.1.1
- Fixed a bug that allowed players to start the Hunting Game in the ship when loading a lobby with the tape inside
- Fixed a bug that allowed the first mini-game to be replayed even after a successful completion
- Fixed an error that occurred when the selected enemy for the Hunting Game didn’t have an EnemyAICollisionDetect or a Renderer on EnemyAICollisionDetect
- Added a check to prevent a Null Reference Exception if Billy’s animator is null
- Increased the default value for the maximum allowed distance a player can move before starting the tape for the Hunting Game mini-game and added a config option to modify this distance

## Version 1.1.0
- Added a new mini-game "Hunting Tape"
- Added a JSON file structure check: if the structure is incorrect, the old file will be renamed with ".old" and the default file will be generated
- Refactored code extensively to allow both mini-games to share common code
- Fixed an issue where the Saw theme would play but not the mini-game if the tape was triggered by someone other than the tested player just before

## Version 1.0.9
- Game version update
- Adding StarlancerAIFix as a dependency
- Fixed a bug with orbiting ship monitors not displaying what they should.
- Changed the player's camp penalty -> spawn a Nutcracker instead of killing the player, the option has been renamed the config file
- Modified monster spawns to be based a little more on the player's height (to avoid spawns on unreachable positions).
- Many changes to the ST.survival_game.json file (don't hesitate to give me feedback on the difficulty of some hordes depending on the rooms you encounter, it's hard to find the right balance!):
	- Addition of numerous monster hordes to provide greater variety and take into account the size of all rooms.
	- Addition of several possible interiors for the Saw game: Toy Store / The Rubber Rooms / Niven Reactor / Storehouse / Gothic Monastery / Chizra Temple / Skaarj Outpost / Guardia Fortress
	- Changed the 'door_name' field to 'doors_names', which now includes a list of door names.
	- delete the ST.survival_game.json file to allow it to regenerate with the new configuration

## Version 1.0.8
- Added a config option to display a tip when a player enters the room, informing them to search for the tape
- Fixed a bug that allowed multiple players to play the mini-game at the same time (players can still be in the room together via teleportation, but only the first player to enter can start the mini-game)
- Fixed a bug where the player’s status (whether they are in the mini-game or not) wasn’t reset if they died before starting the mini-game (e.g., dying in the locked room but before playing the tape)

## Version 1.0.7
- Fixed a bug that prevented the monster wave from spawning
- Adjusted the resting position of Billy
- Added particles around the tape to make it easier to spot until it’s picked up
- Introduced a feature that moves the tape every 30 seconds after the player enters the room. This feature allows for:
	- fixing the issue where the tape would appear behind a door due to a room having a larger collider
	- fixing cases where the tape spawns at a height requiring a ladder
- Added a feature preventing the tested player from being teleported:
	- the teleporter cannot be used on them
	- if they try to teleport using another method (such as a teleport trap), the player will be killed for cheating
- Added support for new interiors: ScarletDevilMansion, StarlancerWarehouse, Nali Haven and Guardia Fortress
	- delete the ST.survival_game.json file to allow it to regenerate with the new configuration

## Version 1.0.6
- Fixed mini-game not resetting if player dies
- Fixed anti-camp system that kills the player if he kills an enemy during the mini-game
- Fixed the music that resumes when player respawns after death
- Fixed an incompatibility with 'Crest' mod

## Version 1.0.5 - Forgot to mention some important details:
- The 'ST.survival_game.json' and 'ST.subtitles.json' files need to be reloaded (updated or deleted to let them recreate themselves)
- Modification of the configuration of two rooms for the haunted mansion with a new horde (more suitable for these rooms)

## Version 1.0.4
- Fixed an incompatibility with the 'Black Mesa Half Life Moon Interior' mod
- Added Billy which spawns at the end of a mini-game, moving toward the player to announce their victory - It's then possible to collect his puppet and sell it
- Added 'billy_value' configuration in the 'ST.survival_game.json' file to set the value of Billy's puppet based on the horde faced
- Added 'min_hour' and 'max_hour' configurations in the 'ST.survival_game.json' file to configure the time range during which a horde can spawn (8:00 = 2 and 0:00 = 18)
- Added 'billy_announcement' section in the 'ST.subtitles.json' file to configure Billy's subtitles
- Added 'weight' configuration in the 'ST.survival_game.json' file to manage the priority order of the rooms in which the mini-game will appear

## Version 1.0.3
- Fixed an incompatibility with ScarletDevilMansion

## Version 1.0.2
- Fixed a NullReferenceException when the SawTheme option in the config was disabled

## Version 1.0.0
- Initial release